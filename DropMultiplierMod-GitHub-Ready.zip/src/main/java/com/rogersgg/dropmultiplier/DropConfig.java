package com.rogersgg.dropmultiplier;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class DropConfig {
    public static int dropMultiplier = 1;

    private static final Gson gson = new Gson();
    private static final File configFile = new File("config/dropmultiplier.json");

    public static void loadConfig() {
        try {
            if (!configFile.exists()) {
                saveDefaultConfig();
            }
            JsonObject json = gson.fromJson(new FileReader(configFile), JsonObject.class);
            dropMultiplier = json.get("dropMultiplier").getAsInt();

            if (dropMultiplier < 1) dropMultiplier = 1;
            if (dropMultiplier > 10000) dropMultiplier = 10000;

        } catch (Exception e) {
            System.out.println("[DropMultiplier] Error reading config, using default.");
            dropMultiplier = 1;
        }
    }

    private static void saveDefaultConfig() {
        try {
            configFile.getParentFile().mkdirs();
            JsonObject defaultJson = new JsonObject();
            defaultJson.addProperty("dropMultiplier", 10); // Default value

            FileWriter writer = new FileWriter(configFile);
            gson.toJson(defaultJson, writer);
            writer.close();
        } catch (Exception e) {
            System.out.println("[DropMultiplier] Error creating default config.");
        }
    }
}