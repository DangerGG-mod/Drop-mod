package com.rogersgg.dropmultiplier;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.Block;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class DropMultiplierMod implements ModInitializer {

    public static final String MOD_ID = "dropmultiplier";

    @Override
    public void onInitialize() {
        DropConfig.loadConfig(); // Load config on start

        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (world instanceof ServerWorld serverWorld) {
                Block block = state.getBlock();
                int multiplier = DropConfig.dropMultiplier;

                if (multiplier > 1) {
                    var drops = Block.getDroppedStacks(state, serverWorld, pos, blockEntity, player, player.getMainHandStack());

                    for (ItemStack drop : drops) {
                        ItemStack multiplied = drop.copy();
                        multiplied.setCount(drop.getCount() * multiplier);
                        Block.dropStack(world, pos, multiplied);
                    }
                }
            }
        });
    }
}